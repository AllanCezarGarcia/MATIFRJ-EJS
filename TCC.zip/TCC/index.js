const express = require("express")
const app = express()

app.set("view engine", "ejs")
app.use(express.static('public'));

app.get("/",(req,res) => {
    res.render("index");
});
app.get("/login",(req,res) => {
    res.render("login");
});
app.get("/registro",(req,res) => {
    res.render("Registro");
});
app.get("/Autenticar",(req,res) => {
    res.render("Autenticar");
});
app.get("/Bimestres",(req,res) => {
    res.render("Bimestres");
});
app.get("/atividades",(req,res) => {
    res.render("atividades");
});
app.get("/alternativas",(req,res) => {
    res.render("alternativas");
});
app.get("/exercicios",(req,res) => {
    res.render("exerciciosAlunos");
});

app.listen(8070,()=>{
    console.log("Servidor Rodando")
})